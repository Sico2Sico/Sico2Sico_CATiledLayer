//
//  ViewController.m
//  CATiledLayeDemo
//
//  Created by 德志 on 2019/4/5.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

#import "ViewController.h"
#import <QuartzCore/QuartzCore.h>
@interface ViewController ()<CALayerDelegate>

@property (nonatomic, strong) UIScrollView * scrollview;

@property (nonatomic, strong) CATiledLayer * imageppLayer;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    //    NSString * path = [[NSBundle mainBundle] pathForResource:@"image" ofType:@"jpg"];
    //    UIImage * imageData = [UIImage imageWithContentsOfFile:path];
    //    UIImageView * imageView = [[UIImageView alloc]initWithImage:imageData];
    //    imageView.frame = self.view.bounds;
    //    [self.view addSubview:imageView];

    self.scrollview = [[UIScrollView alloc]initWithFrame:self.view.bounds];
    [self.view addSubview:self.scrollview];

    self.imageppLayer = [CATiledLayer layer];
    self.imageppLayer.frame = CGRectMake(0, 0, 2048, 2048);
    self.imageppLayer.delegate = self;
    [self.scrollview.layer addSublayer:self.imageppLayer];

    //configure the scroll view
    self.scrollview.contentSize = self.imageppLayer.frame.size;

    //draw layer
    [self.imageppLayer setNeedsDisplay];


}



- (void)drawLayer:(CATiledLayer *)layer inContext:(CGContextRef)ctx
{
    //determine tile coordinate
    CGRect bounds = CGContextGetClipBoundingBox(ctx);
    NSInteger x = floor(bounds.origin.x / layer.tileSize.width);
    NSInteger y = floor(bounds.origin.y / layer.tileSize.height);

    //load tile image
    NSString *imageName = [NSString stringWithFormat: @"image_%02i_%02i", x, y];
    NSString *imagePath = [[NSBundle mainBundle] pathForResource:imageName ofType:@"jpg"];
    UIImage *tileImage = [UIImage imageWithContentsOfFile:imagePath];

    //draw tile
    UIGraphicsPushContext(ctx);
    [tileImage drawInRect:bounds];
    UIGraphicsPopContext();
}

@end
