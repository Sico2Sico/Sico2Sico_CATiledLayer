//
//  CutPictureTool.m
//  CATiledLayeDemo
//
//  Created by 德志 on 2019/4/5.
//  Copyright © 2019 com.aiiage.www. All rights reserved.
//

/// 请 在 Mac 下执行  没有转到iOS上



//#import <AppKit/AppKit.h>
//
//int main(int argc, const char * argv[])
//{
//    @autoreleasepool{
//
//        //input file
//        NSString *inputFile = @"/Users/xxx/Desktop/videoData/xxx/image.jpg";
//
//        //tile size
//        CGSize tileSize = CGSizeMake(900, 289); //output path
//        NSString *outputPath = [inputFile stringByDeletingPathExtension];
//
//        //load image
//        NSImage *image = [[NSImage alloc] initWithContentsOfFile:inputFile];
//        NSSize size = [image size];
//        NSArray *representations = [image representations];
//        if ([representations count]){
//            NSBitmapImageRep *representation = representations[0];
//            size.width = [representation pixelsWide];
//            size.height = [representation pixelsHigh];
//        }
//        NSRect rect = NSMakeRect(0.0, 0.0, size.width, size.height);
//        CGImageRef imageRef = [image CGImageForProposedRect:&rect context:NULL hints:nil];
//
//        //calculate rows and columns
//        NSInteger rows = ceil(size.height / tileSize.height);
//        NSInteger cols = ceil(size.width / tileSize.width)-1;
//
//        //generate tiles
//        for (int y = 0; y < rows; ++y) {
//            for (int x = 0; x < cols; ++x) {
//                //extract tile image
//                CGRect tileRect = CGRectMake(x*tileSize.width, y*tileSize.height, tileSize.width, tileSize.height);
//                CGImageRef tileImage = CGImageCreateWithImageInRect(imageRef, tileRect);
//
//                //convert to jpeg data
//                NSBitmapImageRep *imageRep = [[NSBitmapImageRep alloc] initWithCGImage:tileImage];
//                NSData *data = [imageRep representationUsingType: NSJPEGFileType properties:nil];
//                CGImageRelease(tileImage);
//
//                //save file
//                NSString *path = [outputPath stringByAppendingFormat: @"_%02i_%02i.jpg", x, y];
//                [data writeToFile:path atomically:NO];
//            }
//        }
//    }
//    return 0;
//}
